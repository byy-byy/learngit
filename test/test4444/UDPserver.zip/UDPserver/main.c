#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <unistd.h>

//键盘输入检测函数用到的头文件
#include <stdio.h>
#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

#define SEND_BUF_SIZE 100
#define RECV_BUF_SIZE 100
#define LISTEN_PORT 7801

int kbhit(void);//键盘输入检测函数

int kbhit(void)//键盘有输入返回1，否则返回0，默认为0
{
    struct termios oldt, newt;
    int ch;
    int oldf;
    tcgetattr(STDIN_FILENO, &oldt);
    newt = oldt;
    newt.c_lflag &= ~(ICANON | ECHO);
    tcsetattr(STDIN_FILENO, TCSANOW, &newt);
    oldf = fcntl(STDIN_FILENO, F_GETFL, 0);
    fcntl(STDIN_FILENO, F_SETFL, oldf | O_NONBLOCK);
    ch = getchar();
    tcsetattr(STDIN_FILENO, TCSANOW, &oldt);
    fcntl(STDIN_FILENO, F_SETFL, oldf);
    if(ch != EOF)
    {
        return 1;
    }
    return 0;
}

int main()
{
    //服务器监听的Socket
    int listen_sock = 0;
    //接收数据的内存
    char recvbuf[RECV_BUF_SIZE] = {0};
    //定义接收数据中长度
    int sendlen = 0;
    //本机的socket地址
    struct sockaddr_in hostaddr;
    //客户端的socket地址
    struct sockaddr_in clientaddr;

    memset((void *)&hostaddr,0,sizeof(hostaddr));
    memset((void *)&clientaddr,0,sizeof(clientaddr));

    //设置本机的socket地址
    hostaddr.sin_family = AF_INET;
    hostaddr.sin_port = htons(LISTEN_PORT);
    hostaddr.sin_addr.s_addr = htonl(INADDR_ANY);

    //创建Socket
    listen_sock = socket(AF_INET, SOCK_DGRAM, 0);
    if(listen_sock< 0)
    {
        printf( "create socket failed\n");
        exit(1);
    }

    //绑定Socket
    if(bind(listen_sock, (struct sockaddr *)&hostaddr, sizeof(hostaddr)) < 0)
    {
        printf("bind socket failed\n");
        close(listen_sock);
        exit(1);
    }
    while(1)
    {
        if(!kbhit())
        {
            //接收数据
            int iRealLength = recv(listen_sock, recvbuf, RECV_BUF_SIZE, 0) ;
            if (iRealLength < 0)
            {
                printf("receive data error\n");
                close(listen_sock);
                exit(1);
            }
            printf("receive data is: %s\n",recvbuf);
        }
        if(kbhit())
        {
            //发送数据
            char sendbuf[SEND_BUF_SIZE]={'0'};
            fgets(sendbuf,SEND_BUF_SIZE,stdin);
            sendlen = strlen(sendbuf) + 1;
            sendto(listen_sock, sendbuf, sendlen, 0,(struct sockaddr *)(&clientaddr),sizeof(struct sockaddr_in));
            printf("send data is : %s\n", sendbuf);

        }
    }
    //关闭监听的socket
    close(listen_sock);

    return 0;
}
